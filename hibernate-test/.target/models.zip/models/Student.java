package models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.Max;

import play.data.validation.Constraints.MaxLength;

@Entity
public class Student {
	@Id
	@GeneratedValue
	public int id;
	public String name;
	
	@ManyToOne
	public Teacher teacher;
}
